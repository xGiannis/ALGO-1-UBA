# Este es el primer comentario
def funcion() -> int :
    # Segundo comentario
    a: int = 0
    a = a + a

    #Esto es lo que devuelvo
    return a